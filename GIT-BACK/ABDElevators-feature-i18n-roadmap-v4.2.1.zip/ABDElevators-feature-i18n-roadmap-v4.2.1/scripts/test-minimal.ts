import { connectDB } from '../src/lib/db';
console.log('--- MINIMAL TEST START ---');
console.log('✅ connectDB import success');
console.log('--- MINIMAL TEST END ---');
