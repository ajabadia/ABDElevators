"use client";

import DashboardDispatcher from "@/components/dashboard/DashboardDispatcher";

export default function DashboardPage() {
    return <DashboardDispatcher />;
}

