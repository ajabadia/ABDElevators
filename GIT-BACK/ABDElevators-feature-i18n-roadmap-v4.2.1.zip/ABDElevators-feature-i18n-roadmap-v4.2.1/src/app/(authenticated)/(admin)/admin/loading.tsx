import { DashboardSkeleton } from "@/components/shared/LoadingSkeleton"

export default function AdminLoading() {
    return <DashboardSkeleton />
}
